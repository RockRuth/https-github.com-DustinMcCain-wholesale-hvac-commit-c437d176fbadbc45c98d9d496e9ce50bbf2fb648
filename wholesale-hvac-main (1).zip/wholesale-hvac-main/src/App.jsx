import React, { useState } from 'react';
import { Home, Thermometer, MapPin, Calculator, ShoppingCart, Phone, Flame, Snowflake, Info } from 'lucide-react';

const HVACSizingCalculator = () => {
  const [step, setStep] = useState(1);
  const [state, setState] = useState('');
  const [systemType, setSystemType] = useState('');
  const [heatingType, setHeatingType] = useState('');
  const [flowType, setFlowType] = useState('');
  const [squareFeet, setSquareFeet] = useState('');
  const [currentSize, setCurrentSize] = useState('');
  const [results, setResults] = useState(null);
  const [showTooltip, setShowTooltip] = useState(false);
  const [prices, setPrices] = useState({});
  const [loadingPrices, setLoadingPrices] = useState(false);

  // Images are in the public folder
  const electricHeatPumpImage = '/electric-heat-pump.png';
  const gasFurnaceImage = '/gas-furnace.png';
  const coolingOnlyImage = '/cooling-only.png';
  const heatingAndCoolingImage = '/heating-and-cooling.png';
  const electricBillImage = '/electric-bill-image.png';
  const gasBillImage = '/gas-bill-image.png';
  
  // Furnace placement images
  const horizontalBasementUpflow = '/horizontal-position-furnace-installed-in-basement-flow-is-upflow.png';
  const horizontalAtticDownflow = '/horizontal-position-furnace-installed-in-attic-flow-is-downflow.png';
  const horizontalCrawlspaceUpflow = '/horizontal-position-furnace-installed-in-crawlspace-flow-is-upflow.png';
  const verticalAtticDownflow = '/vertical-position-furnace-installed-in-attic-flow-is-downflow.png';
  const verticalBasementUpflow = '/vertical-position-furnace-installed-in-basement-flow-is-upflow.png';
  const verticalMainFloorHorizontal = '/vertical-position-furnace-installed-on-main-floor-flow-is-horizontal-flow.png';
  
  // Air handler placement images (for electric)
  const ahHorizontalAtticDownflow = '/horizontal-position-air-handler-installed-in-attic-flow-is-downflow.png';
  const ahHorizontalBasementUpflow = '/horizontal-position-air-handler-installed-in-basement-flow-is-upflow.png';
  const ahHorizontalCrawlspaceUpflow = '/horizontal-position-air-handler-installed-in-crawlspace-flow-is-upflow.png';
  const ahVerticalAtticDownflow = '/vertical-position-air-handler-installed-in-attic-flow-is-downflow.png';
  const ahVerticalBasementUpflow = '/vertical-position-air-handler-installed-in-basement-flow-is-upflow.png';
  const ahVerticalMainFloorHorizontal = '/vertical-position-air-handler-installed-on-main-floor-flow-is-horizontal-flow.png';

  const productUrls = {
  ac: {
    silver: {
      '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-air-conditioner-air-handler-system-14-0-seer2-r-32-glxs3bn1810-amst24bu1300/',
      '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-cooling-air-conditioner-air-handler-system-14-0-seer2-r-32-glxs3bn2410-ahve24bp0301/',
      '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-cooling-air-conditioner-air-handler-system-13-8-seer2-r-32-glxs3bn3010-amst30bu1300/',
      '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-0-ton-cooling-air-conditioner-air-handler-system-13-4-seer2-r-32-glxs3bn3610-amst36cu1300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-air-conditioner-air-handler-system-13-5-seer2-r-32-glxs3bn4210-amst42cu1300/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-cooling-air-conditioner-air-handler-system-14-0-seer2-r-32-glxs4ba4810-amst48cu1300/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-air-conditioner-air-handler-system-14-0-seer2-r-32-glxs3bn6010amst60du1300/'
    },
    gold: {
      '1.5': 'https://wholesalehvacdirect.com/product/1-5-ton-14-3-seer2-goodman-straight-cool-air-conditioner-air-handler-split-system-r-32-glxs4ba1810amst24bu1300/',
      '2.0': 'https://wholesalehvacdirect.com/product/2-0-ton-14-3-seer2-goodman-straight-cool-air-conditioner-air-handler-split-system-r-32-glxs4ba2410amst24bu1300/',
      '2.5': 'https://wholesalehvacdirect.com/product/2-5-ton-14-3-seer2-goodman-straight-cool-air-conditioner-air-handler-split-system-r-32-glxs4ba3010amst30bu1300/',
      '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-cooling-air-conditioner-air-handler-system-14-3-seer2-r-32-glxs4ba3610-amst36cu1300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-air-conditioner-air-handler-system-14-3-seer2-r-32-glxs4ba4210-amst42cu1300/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-air-conditioner-air-handler-system-14-3-seer2-r-32-glxs4ba4810-amst48cu1300/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-air-conditioner-air-handler-system-14-3-seer2-r-32-glxs4ba6010-amst60du1300/'
    },
    platinum: {
      '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-15-2-seer2-heat-pump-system-glxs5ba1810-condenser-ahve24bp0300-air-handler-glxs5ba1810-ahve24bp0300/',
      '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-15-2-seer2-heat-pump-system-glxs5ba3010-condenser-ahve36cp0300-air-handler-glxs5ba3010-ahve36cp0300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-13-4-seer2-air-conditioner-only-system-replaces-gsxn3n4210-and-gsx130421-glxs3bn4210-glxs3bn4210-amst42cu1300/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-15-2-seer2-heat-pump-system-glxs5ba4810-condenser-ahve48cp1300-air-handler-glxs5ba4810-ahve48cp1300/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-0-ton-cooling-air-conditioner-air-handler-system-15-2-seer2-r-32-glxs5ba6010ahve60dp1300/'
    }
  },
  heatpump: {
    silver: {
      '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-18k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-5-hspf2-r-32-glzs4ba1810-amst24bu1300-copy/',
      '2.0': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-18k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-5-hspf2-r-32-glzs4ba1810-amst24bu1300/',
      '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-cooling-18k-btu-hr-heating-heat-pump-air-handler-system-14-3-seer2-7-5-hspf2-r-32-glzs4ba3010amst30bu1300/?preview_id=51877&preview_nonce=bda1a50d0d&_thumbnail_id=51242&preview=true',
      '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-cooling-36k-btu-hr-heating-heat-pump-air-handler-system-14-3-seer2-r-32-glzs4ba3610-amst36cu1300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-42k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-8-hspf2-r-32-glzs4ba4210-amst42cu1300/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-0-ton-cooling-48k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-8-hspf2-r-32-glzs4ba4810-amst48cu1300/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-60k-btu-hr-heating-heat-pump-air-handler-system-14-3-seer2-r-32-glzs4ba6010amst60du1300/'
    },
    gold: {
      '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-18k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-5-hspf2-r-32-glzs4ba1810-amst24bu1300/',
      '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-14-3-seer2-heat-pump-system-ac-and-heat-glzs4ba2410-amst24bu1300-glzs4ba2410-amst24bu1300/',
      '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-cooling-30k-btu-hr-heating-heat-pump-air-handler-system-14-5-seer2-7-8-hspf2-r-32-glzs4ba3010-amst30bu1300/',
      '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-0-ton-cooling-36k-btu-hr-heating-heat-pump-air-handler-system-15-0-seer2-7-5-hspf2-r-32-glzs4ba3610-amst36cu1300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-42k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-8-hspf2-r-32-glzs4ba4210-amst42cu1300-2/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-0-ton-cooling-48k-btu-hr-heating-heat-pump-air-handler-system-15-2-seer2-7-8-hspf2-r-32-glzs4ba4810-amst48cu1300-2/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-14-3-seer2-heat-pump-system-ac-and-heat-r-32-glzs4ba6010-amst60du1300/'
    },
    platinum: {
      '1.5': 'https://wholesalehvacdirect.com/product/goodman-ahve24bp0300-2-ton-variable-speed-air-handler-ahve24bp0300/',
      '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-15-2-seer2-heat-pump-system-glzs5ba3010-condenser-ahve36cp0300-air-handler-glzs5ba3010-ahve36cp0300/',
      '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-15-2-seer2-heat-pump-system-glzs5ba4210-condenser-ahve42cp0300-air-handler-glzs5ba4210-ahve42cp0300/',
      '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-15-2-seer2-heat-pump-system-glzs5ba4810-condenser-ahve48cp1300-air-handler-glzs5ba4810-ahve48cp1300/',
      '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-15-2-seer2-heat-pump-system-glzs5ba6010-condenser-ahve60dp1300-air-handler-glzs5ba6010-ahve60dp1300/'
    }
  },
  furnace: {
    upflow: {
      silver: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-13-4-seer2-ac-only-condenser-80-afue-80k-btu-17-5-wide-furnace-with-matched-coil-thermostat-and-disconnect-vertical-upflow-glxs4ba3610-capfa1714a6-gr9s800403ax/',
        '2.0': 'https://wholesalehvacdirect.com/product/2-ton-13-4-seer2-80-afue-60000-btu-goodman-low-nox-gas-furnace-and-r32-air-conditioner-system-upflow/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-13-4-seer2-80-afue-60000-btu-goodman-low-nox-gas-furnace-and-r32-air-conditioner-system-upflow-glxs3bn3010gr9s800603axcapfa3022a3/',
        '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-13-4-seer2-80-afue-60000-btu-goodman-low-nox-gas-furnace-and-r32-air-conditioner-system-upflow-glxs3bn3610gr9s800603bxcapfa3626b3/',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-14-3-seer2-ac-only-condenser-80-afue-80k-btu-17-5-wide-furnace-with-matched-coil-thermostat-and-disconnect-glxs3bn4210gr9s800803bxcapfa4226b3/',
        '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-13-4-seer2-ac-only-condenser-80-afue-80k-btu-17-5-wide-furnace-with-matched-coil-thermostat-and-disconnect-vertical-upflow-glxs3bn4810gr9s800804cxcapfa6030c3/',
        '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-13-4-seer2-ac-only-condenser-80-afue-100k-btu-17-5-wide-furnace-with-matched-coil-thermostat-and-disconnect-upflow-glxs3bn6010gr9s801005cxcapfa6030c3/'
      },
      gold: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-14-3-seer2-92-afue-40000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-upflow-glxs4ba1810gr9s920403ancapfa1714a6/',
        '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-14-3-seer2-92-afue-40000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-upflow-glxs4ba2410gr9s920403ancapfa2422a3/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-14-3-seer2-92-afue-60000-btu-goodman-gas-furnace-and-air-conditioner-system-upflow-r32-glxs4ba3010gr9s920603bncapfa3022b3/',
        '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-14-3-seer2-92-afue-60000-btu-goodman-gas-furnace-and-air-conditioner-system-upflow-r32-glxs4ba3610gr9s920603bncapfa3626b3/',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-air-conditioner-system-upflow-r32-glxs4ba4210gr9s920803bncapfa4226b3/',
        '4.0': 'https://wholesalehvacdirect.com/product/4-ton-14-3-seer2-92-afue-100000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-upflow-glxs4ba4810gr9s921004cncapfa6030c3/',
        '5.0': 'https://wholesalehvacdirect.com/product/5-ton-14-3-seer2-92-afue-120000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-upflow-glxs4ba6010-capfa6030c3-gr9s921205dn/'
      }
    },
    horizontal: {
      silver: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-40000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn1810gr9s800403axchpta1822a3/',
        '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-cooling-40000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn2410gr9s800403axchpta1822a4/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-cooling-60000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn3010gr9s800603bxchpta3026b3/?preview_id=51897&preview_nonce=da877cc1a0&_thumbnail_id=49460&preview=true',
        '3.0': 'https://wholesalehvacdirect.com/?post_type=product&p=51894&preview=true',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-80000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn4210-gr9s800804cxchpta4230c3/',
        '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-cooling-80000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn4810gr9s801205dnchpta6030d3/',
        '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-120000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-13-4-seer2-80-afue-horizontal-r-32-glxs3bn6010gr9s801205dnchpta6030d3/'
      },
      gold: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-cooling-40000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-80-afue-horizontal-r-32-glxs4ba1810gr9s920403anchpta1822a3/',
        '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-cooling-40000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-80-afue-horizontal-r-32-glxs4ba2410-gr9s920403an-chpta1822a4/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-cooling-60000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-80-afue-horizontal-r-32-glxs4ba3010gr9s920603bnchpta3026b3/',
        '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-cooling-60000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-80-afue-horizontal-r-32-glxs4ba3610-gr9s920603bn-chpta3630b3/',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-cooling-100000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-92-afue-horizontal-r-32-glxs4ba4210-gr9s921004cn-chpta4230c3/',
        '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-cooling-120000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-92-afue-horizontal-r-32-glxs4ba4810-gr9s921205dn-chpta6030d3/',
        '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-cooling-120000-btu-hr-heating-air-conditioner-multi-speed-furnace-system-14-3-seer2-92-afue-horizontal-r-32-glxs4ba6010-gr9s921205dn-chpta6030d4/'
      }
    },
    downflow: {
      silver: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-13-4-seer2-80-afue-40000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn1810gc9s800403axcapfa1818c3/',
        '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-13-4-seer2-80-afue-40000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn2410gc9s800403axcapfa2422a3/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-13-4-seer2-80-afue-80000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn3010gc9s800804bxcapfa3022b3/',
        '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-13-4-seer2-80-afue-80000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn3610gc9s800804bxcapfa3626b3/',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-13-4-seer2-80-afue-80000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn4210gc9s800805cxcapfa4226c3/',
        '4.0': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-13-4-seer2-80-afue-80000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn4810gc9s801005cxcapfa6030c3/',
        '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-13-4-seer2-80-afue-120000-btu-low-nox-gas-furnace-and-r32-air-conditioner-system-downflow-glxs3bn6010gm9c801205dncapfa6030d3/'
      },
      gold: {
        '1.5': 'https://wholesalehvacdirect.com/product/goodman-1-5-ton-14-3-seer2-92-afue-40000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba1810gc9s800403axcapfa1818c3/',
        '2.0': 'https://wholesalehvacdirect.com/product/goodman-2-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba2410gc9s800403axcapfa2422a3/',
        '2.5': 'https://wholesalehvacdirect.com/product/goodman-2-5-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba3010gr9s800803bcapta2422b3-copy/',
        '3.0': 'https://wholesalehvacdirect.com/product/goodman-3-ton-14-3-seer2-92-afue-60000-btu-goodman-gas-furnace-and-air-conditioner-system-upflow-r32-glxs4ba3610gc9s800804bxcapfa3626b3/',
        '3.5': 'https://wholesalehvacdirect.com/product/goodman-3-5-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba4210gc9s800805cxcapfa4226c3/',
        '4.0': 'https://wholesalehvacdirect.com/product/goodman-4-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba4810gc9s801005cxcapfa6030c3/',
        '5.0': 'https://wholesalehvacdirect.com/product/goodman-5-ton-14-3-seer2-92-afue-80000-btu-goodman-gas-furnace-and-r32-air-conditioner-system-downflow-glxs4ba6010gm9c801205dncapfa6030d3/'
      }
    }
  }
};

  const hvacSystems = {
  ac: {
    silver: [
      { tonnage: '1.5', ac: 'GLXS3BN1810', airHandler: 'AMST24BU1300', seer: '13.4' },
      { tonnage: '2.0', ac: 'GLXS3BN2410', airHandler: 'AHVE24BP0301', seer: '13.4' },
      { tonnage: '2.5', ac: 'GLXS3BN3010', airHandler: 'AMST30BU1300', seer: '13.4' },
      { tonnage: '3.0', ac: 'GLXS3BN3610', airHandler: 'AMST36CU1300', seer: '13.4' },
      { tonnage: '3.5', ac: 'GLXS3BN4210', airHandler: 'AMST42CU1300', seer: '13.4' },
      { tonnage: '4.0', ac: 'GLXS4BA4810', airHandler: 'AMST48CU1300', seer: '13.4' },
      { tonnage: '5.0', ac: 'GLXS3BN6010', airHandler: 'AMST60DU1300', seer: '13.4' }
    ],
    gold: [
      { tonnage: '1.5', ac: 'GLXS4BA1810', airHandler: 'AMST24BU1300', seer: '14.3' },
      { tonnage: '2.0', ac: 'GLXS4BA2410', airHandler: 'AMST24BU1300', seer: '14.3' },
      { tonnage: '2.5', ac: 'GLXS4BA3010', airHandler: 'AMST30BU1300', seer: '14.3' },
      { tonnage: '3.0', ac: 'GLXS4BA3610', airHandler: 'AMST36CU1300', seer: '14.3' },
      { tonnage: '3.5', ac: 'GLXS4BA4210', airHandler: 'AMST42CU1300', seer: '14.3' },
      { tonnage: '4.0', ac: 'GLXS4BA4810', airHandler: 'AMST48CU1300', seer: '14.3' },
      { tonnage: '5.0', ac: 'GLXS4BA6010', airHandler: 'AMST60DU1300', seer: '14.3' }
    ],
    platinum: [
      { tonnage: '1.5', ac: 'GLXS5BA1810', airHandler: 'AHVE24BP0300', seer: '15.2' },
      { tonnage: '2.0', ac: 'GLXS5BA2410', airHandler: 'AHVE24BP0301', seer: '15.2' },
      { tonnage: '2.5', ac: 'GLXS5BA3010', airHandler: 'AHVE36CP0300', seer: '15.2' },
      { tonnage: '3.0', ac: 'GLXS5BA3610', airHandler: 'AHVE36CP0301', seer: '15.2' },
      { tonnage: '3.5', ac: 'GLXS5BA4210', airHandler: 'AHVE42CP0300', seer: '15.2' },
      { tonnage: '4.0', ac: 'GLXS5BA4810', airHandler: 'AHVE48CP1300', seer: '15.2' },
      { tonnage: '5.0', ac: 'GLXS5BA6010', airHandler: 'AHVE60DP1300', seer: '15.2' }
    ]
  },
  heatpump: {
    silver: [
      { tonnage: '1.5', heatpump: 'GLZS4BA1810', airHandler: 'AMST24BU1300', seer: '14.3' },
      { tonnage: '2.0', heatpump: 'GLZS4BA2410', airHandler: 'AMST24BU1300', seer: '14.3' },
      { tonnage: '2.5', heatpump: 'GLZS4BA3010', airHandler: 'AMST30BU1300', seer: '14.3' },
      { tonnage: '3.0', heatpump: 'GLZS4BA3610', airHandler: 'AMST36CU1300', seer: '14.3' },
      { tonnage: '3.5', heatpump: 'GLZS4BA4210', airHandler: 'AMST42CU1300', seer: '14.3' },
      { tonnage: '4.0', heatpump: 'GLZS4BA4810', airHandler: 'AMST48CU1300', seer: '14.3' },
      { tonnage: '5.0', heatpump: 'GLZS4BA6010', airHandler: 'AMST60DU1300', seer: '14.3' }
    ],
    gold: [
      { tonnage: '1.5', heatpump: 'GLZS5BA1810', airHandler: 'AMST24BU1300', seer: '15.2' },
      { tonnage: '2.0', heatpump: 'GLZS5BA2410', airHandler: 'AMST24BU1300', seer: '15.2' },
      { tonnage: '2.5', heatpump: 'GLZS5BA3010', airHandler: 'AMST30BU1300', seer: '15.2' },
      { tonnage: '3.0', heatpump: 'GLZS5BA3610', airHandler: 'AMST36CU1300', seer: '15.2' },
      { tonnage: '3.5', heatpump: 'GLZS5BA4210', airHandler: 'AMST42CU1300', seer: '15.2' },
      { tonnage: '4.0', heatpump: 'GLZS5BA4810', airHandler: 'AMST48CU1300', seer: '15.2' },
      { tonnage: '5.0', heatpump: 'GLZS5BA6010', airHandler: 'AMST60DU1300', seer: '15.2' }
    ],
    platinum: [
      { tonnage: '2.0', heatpump: 'GLZS5BA2410', airHandler: 'AHVE24BP0301', seer: '16.0' },
      { tonnage: '2.5', heatpump: 'GLZS5BA3010', airHandler: 'AHVE36CP0300', seer: '16.0' },
      { tonnage: '3.0', heatpump: 'GLZS5BA3610', airHandler: 'AHVE36CP0301', seer: '16.0' },
      { tonnage: '3.5', heatpump: 'GLZS5BA4210', airHandler: 'AHVE42CP0300', seer: '16.0' },
      { tonnage: '4.0', heatpump: 'GLZS5BA4810', airHandler: 'AHVE48CP1300', seer: '16.0' },
      { tonnage: '5.0', heatpump: 'GLZS5BA6010', airHandler: 'AHVE60DP1300', seer: '16.0' }
    ]
  },
  furnace: {
    upflow: {
      silver: [
        { tonnage: '1.5', ac: 'GLXS3BN1810', furnace: 'GR9S800403AX', coil: 'CAPFA1714A6', seer: '13.4', afue: '80%' },
        { tonnage: '2.0', ac: 'GLXS3BN2410', furnace: 'GR9S800403AX', coil: 'CAPFA2422A3', seer: '13.4', afue: '80%' },
        { tonnage: '2.5', ac: 'GLXS3BN3010', furnace: 'GR9S800603AX', coil: 'CAPFA3022A3', seer: '13.4', afue: '80%' },
        { tonnage: '3.0', ac: 'GLXS3BN3610', furnace: 'GR9S800603BX', coil: 'CAPFA3626B3', seer: '13.4', afue: '80%' },
        { tonnage: '3.5', ac: 'GLXS3BN4210', furnace: 'GR9S800803BX', coil: 'CAPFA4226B3', seer: '13.4', afue: '80%' },
        { tonnage: '4.0', ac: 'GLXS3BN4810', furnace: 'GR9S800804CX', coil: 'CAPFA6030C3', seer: '13.4', afue: '80%' },
        { tonnage: '5.0', ac: 'GLXS3BN6010', furnace: 'GR9S801005CX', coil: 'CAPFA6030C3', seer: '13.4', afue: '80%' }
      ],
      gold: [
        { tonnage: '1.5', ac: 'GLXS4BA1810', furnace: 'GR9S920403AN', coil: 'CAPFA1714A6', seer: '14.3', afue: '92%' },
        { tonnage: '2.0', ac: 'GLXS4BA2410', furnace: 'GR9S920403AN', coil: 'CAPFA2422A3', seer: '14.3', afue: '92%' },
        { tonnage: '2.5', ac: 'GLXS4BA3010', furnace: 'GR9S920603BN', coil: 'CAPFA3022B3', seer: '14.3', afue: '92%' },
        { tonnage: '3.0', ac: 'GLXS4BA3610', furnace: 'GR9S920603BN', coil: 'CAPFA3626B3', seer: '14.3', afue: '92%' },
        { tonnage: '3.5', ac: 'GLXS4BA4210', furnace: 'GR9S920803BN', coil: 'CAPFA4226B3', seer: '14.3', afue: '92%' },
        { tonnage: '4.0', ac: 'GLXS4BA4810', furnace: 'GR9S921004CN', coil: 'CAPFA6030C3', seer: '14.3', afue: '92%' },
        { tonnage: '5.0', ac: 'GLXS4BA6010', furnace: 'GR9S921205DN', coil: 'CAPFA6030C3', seer: '14.3', afue: '92%' }
      ]
    },
    horizontal: {
      silver: [
        { tonnage: '1.5', ac: 'GLXS3BN1810', furnace: 'GR9S800403AX', coil: 'CHPTA1822A3', seer: '13.4', afue: '80%' },
        { tonnage: '2.0', ac: 'GLXS3BN2410', furnace: 'GR9S800403AX', coil: 'CHPTA1822A4', seer: '13.4', afue: '80%' },
        { tonnage: '2.5', ac: 'GLXS3BN3010', furnace: 'GR9S800603BX', coil: 'CHPTA3026B3', seer: '13.4', afue: '80%' },
        { tonnage: '3.0', ac: 'GLXS3BN3610', furnace: 'GR9S800804CX', coil: 'CHPTA3630B3', seer: '13.4', afue: '80%' },
        { tonnage: '3.5', ac: 'GLXS3BN4210', furnace: 'GR9S800804CX', coil: 'CHPTA4230C3', seer: '13.4', afue: '80%' },
        { tonnage: '4.0', ac: 'GLXS3BN4810', furnace: 'GR9S801205DN', coil: 'CHPTA6030D3', seer: '13.4', afue: '80%' },
        { tonnage: '5.0', ac: 'GLXS3BN6010', furnace: 'GR9S801205DN', coil: 'CHPTA6030D3', seer: '13.4', afue: '80%' }
      ],
      gold: [
        { tonnage: '1.5', ac: 'GLXS4BA1810', furnace: 'GR9S920403AN', coil: 'CHPTA1822A3', seer: '14.3', afue: '92%' },
        { tonnage: '2.0', ac: 'GLXS4BA2410', furnace: 'GR9S920403AN', coil: 'CHPTA1822A4', seer: '14.3', afue: '92%' },
        { tonnage: '2.5', ac: 'GLXS4BA3010', furnace: 'GR9S920603BN', coil: 'CHPTA3026B3', seer: '14.3', afue: '92%' },
        { tonnage: '3.0', ac: 'GLXS4BA3610', furnace: 'GR9S920603BN', coil: 'CHPTA3630B3', seer: '14.3', afue: '92%' },
        { tonnage: '3.5', ac: 'GLXS4BA4210', furnace: 'GR9S921004CN', coil: 'CHPTA4230C3', seer: '14.3', afue: '92%' },
        { tonnage: '4.0', ac: 'GLXS4BA4810', furnace: 'GR9S921205DN', coil: 'CHPTA6030D3', seer: '14.3', afue: '92%' },
        { tonnage: '5.0', ac: 'GLXS4BA6010', furnace: 'GR9S921205DN', coil: 'CHPTA6030D4', seer: '14.3', afue: '92%' }
      ]
    },
    downflow: {
      silver: [
        { tonnage: '1.5', ac: 'GLXS3BN1810', furnace: 'GC9S800403AX', coil: 'CAPFA1818C3', seer: '13.4', afue: '80%' },
        { tonnage: '2.0', ac: 'GLXS3BN2410', furnace: 'GC9S800403AX', coil: 'CAPFA2422A3', seer: '13.4', afue: '80%' },
        { tonnage: '2.5', ac: 'GLXS3BN3010', furnace: 'GC9S800804BX', coil: 'CAPFA3022B3', seer: '13.4', afue: '80%' },
        { tonnage: '3.0', ac: 'GLXS3BN3610', furnace: 'GC9S800804BX', coil: 'CAPFA3626B3', seer: '13.4', afue: '80%' },
        { tonnage: '3.5', ac: 'GLXS3BN4210', furnace: 'GC9S800805CX', coil: 'CAPFA4226C3', seer: '13.4', afue: '80%' },
        { tonnage: '4.0', ac: 'GLXS3BN4810', furnace: 'GC9S801005CX', coil: 'CAPFA6030C3', seer: '13.4', afue: '80%' },
        { tonnage: '5.0', ac: 'GLXS3BN6010', furnace: 'GM9C801205DN', coil: 'CAPFA6030D3', seer: '13.4', afue: '80%' }
      ],
      gold: [
        { tonnage: '1.5', ac: 'GLXS4BA1810', furnace: 'GC9S800403AX', coil: 'CAPFA1818C3', seer: '14.3', afue: '80%' },
        { tonnage: '2.0', ac: 'GLXS4BA2410', furnace: 'GC9S800403AX', coil: 'CAPFA2422A3', seer: '14.3', afue: '80%' },
        { tonnage: '2.5', ac: 'GLXS4BA3010', furnace: 'GC9S800804BX', coil: 'CAPFA3022B3', seer: '14.3', afue: '80%' },
        { tonnage: '3.0', ac: 'GLXS4BA3610', furnace: 'GC9S800804BX', coil: 'CAPFA3626B3', seer: '14.3', afue: '80%' },
        { tonnage: '3.5', ac: 'GLXS4BA4210', furnace: 'GC9S800805CX', coil: 'CAPFA4226C3', seer: '14.3', afue: '80%' },
        { tonnage: '4.0', ac: 'GLXS4BA4810', furnace: 'GC9S801005CX', coil: 'CAPFA6030C3', seer: '14.3', afue: '80%' },
        { tonnage: '5.0', ac: 'GLXS4BA6010', furnace: 'GM9C801205DN', coil: 'CAPFA6030D3', seer: '14.3', afue: '80%' }
      ]
    }
  }
};

  const states = ['Alabama', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];

  const thresholds = [
  [1.77, '1.5'],  // up to 850 sqft
  [2.40, '2.0'],  // up to 1150 sqft
  [3.02, '2.5'],  // up to 1450 sqft
  [3.65, '3.0'],  // up to 1750 sqft
  [4.27, '3.5'],  // up to 2050 sqft
  [4.90, '4.0'],  // up to 2350 sqft
  // 5.0 ton is handled by the default for anything above 4.90
];

  const calculateTonnage = (sqft) => {
    if (!sqft) return;
    const btus = sqft * 25;
    const tons = btus / 12000;
    const found = thresholds.find(([limit]) => tons <= limit);
    return found ? found[1] : "5.0";
  };

  const getProductUrl = (tier, tonnage, resultData = results) => {
    if (!resultData) return null;
    
    if (resultData.systemType === 'coolingOnly') {
      return productUrls.ac?.[tier]?.[tonnage];
    } else if (resultData.heatingType === 'electric') {
      return productUrls.heatpump?.[tier]?.[tonnage];
    } else if (resultData.heatingType === 'gas') {
      return productUrls.furnace?.[resultData.flowType]?.[tier]?.[tonnage];
    }
    return null;
  };

  // Function to fetch price from Netlify function
  const fetchPrice = async (url) => {
    if (!url) return null;
    
    try {
      const response = await fetch(`/.netlify/functions/fetch-price?url=${encodeURIComponent(url)}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.price;
    } catch (error) {
      console.error(`Error fetching price from ${url}:`, error);
      return null;
    }
  };

  // Function to fetch all prices for current results
  const fetchAllPrices = async (resultData) => {
    setLoadingPrices(true);
    const newPrices = {};
    
    const tierTonnagePairs = [
      ['silver', resultData.silver?.tonnage],
      ['gold', resultData.gold?.tonnage],
      ['platinum', resultData.platinum?.tonnage]
    ];
    
    for (const [tier, tonnage] of tierTonnagePairs) {
      if (tonnage) {
        const url = getProductUrl(tier, tonnage, resultData);
        if (url) {
          const price = await fetchPrice(url);
          newPrices[`${tier}-${tonnage}`] = price;
        }
      }
    }
    
    setPrices(newPrices);
    setLoadingPrices(false);
  };

  const handleCalculate = () => {
    let tonnage = currentSize || calculateTonnage(parseInt(squareFeet));
    const isCalifornia = state === 'California';
    let silver, gold, platinum;

    if (systemType === 'coolingOnly') {
      const systems = hvacSystems.ac;
      silver = systems.silver.find(s => s.tonnage === tonnage);
      gold = systems.gold.find(s => s.tonnage === tonnage);
      platinum = systems.platinum.find(s => s.tonnage === tonnage);
      if (isCalifornia && silver?.seer === '13.4') silver = null;
    } else if (heatingType === 'electric') {
      const systems = hvacSystems.heatpump;
      silver = systems.silver.find(s => s.tonnage === tonnage);
      gold = systems.gold.find(s => s.tonnage === tonnage);
      platinum = systems.platinum.find(s => s.tonnage === tonnage);
    } else if (heatingType === 'gas') {
      const systems = hvacSystems.furnace[flowType];
      silver = systems.silver.find(s => s.tonnage === tonnage);
      gold = systems.gold.find(s => s.tonnage === tonnage);
      platinum = null;
      if (isCalifornia && silver?.seer === '13.4') silver = null;
    }

    const resultData = { tonnage, silver, gold, platinum, systemType, heatingType, flowType, state };
    setResults(resultData);
    setStep(5);
    
    // Fetch prices after setting results
    fetchAllPrices(resultData);
  };

  const resetCalculator = () => {
    setStep(1);
    setState('');
    setSystemType('');
    setHeatingType('');
    setFlowType('');
    setSquareFeet('');
    setCurrentSize('');
    setResults(null);
    setPrices({});
    setLoadingPrices(false);
  };

  const SystemCard = ({ system, tier, tierName, tierBg }) => {
    if (!system) return null;
    const productUrl = getProductUrl(tier, system.tonnage);
    const isFurnace = heatingType === 'gas';
    const priceKey = `${tier}-${system.tonnage}`;
    const price = prices[priceKey];
    
    return (
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className={`${tierBg} text-white p-4`}>
          <h3 className="text-2xl font-bold">{tierName}</h3>
          <p className="text-sm">
            {tier === 'silver' && system.seer === '13.4' 
              ? 'Lowest Cost Guaranteed, Best Recommended, Most Popular'
              : tier === 'platinum' 
              ? 'Highest Efficiency, Total Comfort' 
              : tier === 'gold' 
              ? 'Higher Energy Efficient Choice' 
              : 'Increased Efficiency, Competitive Price'}
          </p>
        </div>
        <div className="p-6">
          {/* Price Display */}
          {loadingPrices ? (
            <div className="mb-6 p-4 bg-blue-50 rounded-lg text-center">
              <div className="animate-pulse text-blue-600 font-semibold">Loading price...</div>
            </div>
          ) : price ? (
            <div className="mb-6 p-4 bg-green-50 rounded-lg border-2 border-green-200">
              <div className="text-sm text-gray-600 mb-1">Online Price</div>
              <div className="text-4xl font-bold text-green-600">${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
              <div className="text-xs text-gray-500 mt-1">Price shown is from online store</div>
            </div>
          ) : (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg border-2 border-gray-200">
              <div className="text-sm text-gray-600 mb-1">Pricing</div>
              <div className="text-lg font-semibold text-gray-700">Call for Quote</div>
            </div>
          )}
          
          <div className="mb-6">
            <div className="text-sm text-gray-600 mb-1">SEER2 Rating</div>
            <div className="text-3xl font-bold text-blue-600">{system.seer}</div>
            {isFurnace && system.afue && (
              <div className="mt-2">
                <div className="text-sm text-gray-600">AFUE Rating</div>
                <div className="text-2xl font-bold text-orange-600">{system.afue}</div>
              </div>
            )}
          </div>
          <ul className="space-y-2 mb-6 text-sm text-gray-700">
            <li>• {system.seer} SEER2 {tier === 'silver' ? 'Single Stage' : tier === 'gold' ? 'Two Stage' : 'Inverter Variable'} Compressor</li>
            {isFurnace ? (
              <li>• {system.afue} AFUE Gas Furnace</li>
            ) : (
              <li>• {tier === 'platinum' ? 'Variable Speed Indoor Fan' : 'Multi-Speed Air Handler'}</li>
            )}
          </ul>
          
          <div className="pt-4 border-t">
            <div className="text-xs font-semibold text-gray-600 mb-2">Part Numbers:</div>
            <div className="text-xs space-y-1 text-gray-700 mb-6">
              <div><span className="font-medium">{systemType === 'coolingOnly' ? 'A/C Unit' : heatingType === 'electric' ? 'Heat Pump Unit' : 'A/C Unit'}:</span> {system.ac || system.heatpump}</div>
              {isFurnace ? (
                <>
                  <div><span className="font-medium">Furnace:</span> {system.furnace}</div>
                  <div><span className="font-medium">Coil:</span> {system.coil}</div>
                </>
              ) : (
                <div><span className="font-medium">Air Handler:</span> {system.airHandler}</div>
              )}
            </div>
          </div>

          <div className="mt-4">
            {productUrl ? (
              <a href={productUrl} target="_blank" rel="noopener noreferrer" className="block w-full text-center py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition">
                <ShoppingCart className="w-5 h-5 inline mr-2" />
                View Pricing & Buy Now
              </a>
            ) : (
              <a href="tel:3802101441" className="block w-full text-center py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition">
                <Phone className="w-5 h-5 inline mr-2" />
                Call for Pricing
              </a>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto py-4 px-4">
          <div className="flex justify-between items-center">
            <a href="https://wholesalehvacdirect.com" target="_blank" rel="noopener noreferrer">
              <img 
                src="https://wholesalehvacdirect.com/wp-content/uploads/2025/01/image.webp" 
                alt="Wholesale HVAC Direct" 
                className="h-16 md:h-20 object-contain hover:opacity-80 transition"
              />
            </a>
            <a 
              href="tel:3802101441" 
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 md:px-6 md:py-3 rounded-lg font-semibold hover:bg-blue-700 transition shadow-md"
            >
              <Phone className="w-5 h-5" />
              <span className="hidden sm:inline">(380) 210-1441</span>
              <span className="sm:hidden">Call</span>
            </a>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2 inline-block pb-2" style={{ borderBottom: '4px solid #E9791C' }}>Smart HVAC System Selector</h1>
            <p className="text-lg text-gray-700 mt-4"><strong>NO HVAC KNOWLEDGE REQUIRED</strong> - Select the Right System for Your Home or Property</p>
          </div>

          {step < 5 && (
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <div className="flex items-center justify-between max-w-xl mx-auto">
                {[1, 2, 3, 4].map((s) => (
                  <React.Fragment key={s}>
                    <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                      step >= s || (s === 3 && step === 3.5) ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                    } font-semibold`}>{s}</div>
                    {s < 4 && <div className={`flex-1 h-1 mx-2 ${
                      step > s || (s === 3 && step === 3.5) ? 'bg-blue-600' : 'bg-gray-300'
                    }`} />}
                  </React.Fragment>
                ))}
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
              <div className="flex items-center mb-6">
                <MapPin className="w-8 h-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Select Your State</h2>
              </div>
              <select value={state} onChange={(e) => setState(e.target.value)} className="w-full p-4 border-2 border-gray-300 rounded-lg text-lg focus:border-blue-500 focus:outline-none">
                <option value="">Choose your state...</option>
                {states.map((s) => (<option key={s} value={s}>{s}</option>))}
              </select>
              {state === 'California' && (<p className="mt-4 text-sm text-blue-600 bg-blue-50 p-3 rounded">California requires minimum 14.3 SEER2 rating</p>)}
              <button onClick={() => setStep(2)} disabled={!state} className="w-full mt-6 py-4 bg-blue-600 text-white rounded-lg font-semibold text-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition">Continue</button>
            </div>
          )}

          {step === 2 && (
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
              <div className="flex items-center justify-center mb-6">
                <Thermometer className="w-8 h-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Do you have an electric or gas bill for your HVAC needs?</h2>
                <div className="relative ml-2">
                  <Info 
                    className="w-5 h-5 text-gray-400 cursor-help" 
                    onMouseEnter={() => setShowTooltip(true)}
                    onMouseLeave={() => setShowTooltip(false)}
                  />
                  {showTooltip && (
                    <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 w-64 bg-gray-900 text-white text-sm p-3 rounded-lg shadow-xl z-10">
                      <div className="absolute right-full top-1/2 -translate-y-1/2 border-8 border-transparent border-r-gray-900"></div>
                      If you pay a gas bill for your furnace, click Gas. If you ONLY have an electric bill, click Electric.
                    </div>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <button 
                  onClick={() => {
                    setSystemType('coolingHeating');
                    setHeatingType('electric');
                    setStep(3);
                  }} 
                  className={`relative p-4 border-2 rounded-lg transition-all duration-300 overflow-hidden ${
                    heatingType === 'electric' 
                      ? 'border-blue-600 shadow-lg transform scale-105 ring-2 ring-blue-400' 
                      : 'border-gray-300 hover:border-blue-400 hover:shadow-md hover:scale-102'
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br from-blue-400 to-blue-600 transition-opacity duration-300 ${
                    heatingType === 'electric' ? 'opacity-10' : 'opacity-0'
                  }`}></div>
                  <div className="relative z-10">
                    <div className="bg-white rounded-lg p-3 mb-4">
                      <img src={electricBillImage} alt="Electric Bill" className="w-full h-auto rounded" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Electric</h3>
                    <p className="text-sm text-gray-600">All electric</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setSystemType('coolingHeating');
                    setHeatingType('gas');
                    setStep(3.5);
                  }} 
                  className={`relative p-4 border-2 rounded-lg transition-all duration-300 overflow-hidden ${
                    heatingType === 'gas' 
                      ? 'border-orange-600 shadow-lg transform scale-105 ring-2 ring-orange-400' 
                      : 'border-gray-300 hover:border-orange-400 hover:shadow-md hover:scale-102'
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br from-orange-400 to-red-500 transition-opacity duration-300 ${
                    heatingType === 'gas' ? 'opacity-10' : 'opacity-0'
                  }`}></div>
                  <div className="relative z-10">
                    <div className="bg-white rounded-lg p-3 mb-4">
                      <img src={gasBillImage} alt="Gas Bill" className="w-full h-auto rounded" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">Gas</h3>
                    <p className="text-sm text-gray-600">Gas furnace with AC system</p>
                  </div>
                </button>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(1)} className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold text-lg hover:bg-gray-50 transition">Back</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-6xl mx-auto">
              <div className="flex items-center mb-6">
                <Home className="w-8 h-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Air Handler Position & Placement</h2>
              </div>
              <p className="text-gray-600 mb-6 text-center">Select the position and location of your air handler</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahHorizontalBasementUpflow} alt="Horizontal - Basement" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Basement</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
                
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahHorizontalCrawlspaceUpflow} alt="Horizontal - Crawlspace" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Crawlspace</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
                
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahHorizontalAtticDownflow} alt="Horizontal - Attic" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Attic</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
                
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahVerticalBasementUpflow} alt="Vertical - Basement" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Basement</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
                
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahVerticalMainFloorHorizontal} alt="Vertical - Main Floor" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Main Floor</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
                
                <button onClick={() => setStep(4)} className="p-4 border-2 rounded-lg transition border-gray-300 hover:border-blue-400">
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={ahVerticalAtticDownflow} alt="Vertical - Attic" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Attic</h3>
                  <p className="text-sm text-gray-600">Multi-position air handler</p>
                </button>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(2)} className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold text-lg hover:bg-gray-50 transition">Back</button>
              </div>
            </div>
          )}

          {step === 3.5 && (
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-6xl mx-auto">
              <div className="flex items-center mb-6">
                <Home className="w-8 h-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Furnace Position & Placement</h2>
              </div>
              <p className="text-gray-600 mb-6 text-center">Select the position and location of your furnace</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <button onClick={() => {setFlowType('upflow'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'upflow' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={horizontalBasementUpflow} alt="Horizontal - Basement" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Basement</h3>
                  <p className="text-sm text-gray-600">Upflow configuration</p>
                </button>
                
                <button onClick={() => {setFlowType('upflow'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'upflow' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={horizontalCrawlspaceUpflow} alt="Horizontal - Crawlspace" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Crawlspace</h3>
                  <p className="text-sm text-gray-600">Upflow configuration</p>
                </button>
                
                <button onClick={() => {setFlowType('downflow'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'downflow' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={horizontalAtticDownflow} alt="Horizontal - Attic" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Horizontal - Attic</h3>
                  <p className="text-sm text-gray-600">Downflow configuration</p>
                </button>
                
                <button onClick={() => {setFlowType('upflow'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'upflow' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={verticalBasementUpflow} alt="Vertical - Basement" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Basement</h3>
                  <p className="text-sm text-gray-600">Upflow configuration</p>
                </button>
                
                <button onClick={() => {setFlowType('horizontal'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'horizontal' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={verticalMainFloorHorizontal} alt="Vertical - Main Floor" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Main Floor</h3>
                  <p className="text-sm text-gray-600">Horizontal flow configuration</p>
                </button>
                
                <button onClick={() => {setFlowType('downflow'); setStep(4);}} className={`p-4 border-2 rounded-lg transition ${flowType === 'downflow' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-400'}`}>
                  <div className="bg-white rounded-lg p-3 mb-4">
                    <img src={verticalAtticDownflow} alt="Vertical - Attic" className="w-full h-auto rounded" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Vertical - Attic</h3>
                  <p className="text-sm text-gray-600">Downflow configuration</p>
                </button>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(2)} className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold text-lg hover:bg-gray-50 transition">Back</button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
              <div className="flex items-center mb-6">
                <Home className="w-8 h-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-bold text-gray-800">Home Size</h2>
              </div>
              <div className="mb-6">
                <label className="block text-lg font-semibold mb-3">Enter your home square footage</label>
                <input type="number" value={squareFeet} onChange={(e) => { setSquareFeet(e.target.value); if (e.target.value) setCurrentSize(''); }} placeholder="e.g., 1200" className="w-full p-4 border-2 border-gray-300 rounded-lg text-lg focus:border-blue-500 focus:outline-none" />
                <p className="mt-2 text-sm text-gray-600">We will calculate the recommended system size based on 25 BTUs per square foot</p>
              </div>
              <div className="text-center my-4 text-gray-500 font-semibold">OR</div>
              <div className="mb-6">
                <label className="block text-lg font-semibold mb-3">Know your current system size?</label>
                <select value={currentSize} onChange={(e) => { setCurrentSize(e.target.value); if (e.target.value) setSquareFeet(''); }} className="w-full p-4 border-2 border-gray-300 rounded-lg text-lg focus:border-blue-500 focus:outline-none">
                  <option value="">Select tonnage...</option>
                  <option value="1.5">1.5 Ton</option>
                  <option value="2.0">2.0 Ton</option>
                  <option value="2.5">2.5 Ton</option>
                  <option value="3.0">3.0 Ton</option>
                  <option value="3.5">3.5 Ton</option>
                  <option value="4.0">4.0 Ton</option>
                  <option value="5.0">5.0 Ton</option>
                </select>
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => {
                  if (heatingType === 'gas') setStep(3.5);
                  else if (heatingType === 'electric') setStep(3);
                  else setStep(2);
                }} className="flex-1 py-4 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold text-lg hover:bg-gray-50 transition">Back</button>
                <button onClick={handleCalculate} disabled={!currentSize && !squareFeet} className="flex-1 py-4 bg-blue-600 text-white rounded-lg font-semibold text-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition">
                  <Calculator className="w-5 h-5 inline mr-2" />
                  Calculate
                </button>
              </div>
            </div>
          )}

          {step === 5 && results && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-lg p-6 text-center">
                <h2 className="text-3xl font-bold text-gray-800 mb-2">
                  Recommended: {results.tonnage} Ton {
                    results.systemType === 'coolingOnly' ? 'Air Conditioner' : 
                    results.heatingType === 'electric' ? 'Heat Pump' : 
                    `Gas Furnace System (${results.flowType === 'upflow' ? 'Vertical UpFlow' : results.flowType === 'horizontal' ? 'Horizontal' : 'DownFlow'})`
                  }
                </h2>
                <p className="text-gray-600">Based on your home in {results.state}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {results.silver && <SystemCard system={results.silver} tier="silver" tierName="Silver" tierBg="bg-gray-400" />}
                {results.gold && <SystemCard system={results.gold} tier="gold" tierName="Gold" tierBg="bg-yellow-500" />}
                {results.platinum && <SystemCard system={results.platinum} tier="platinum" tierName="Platinum" tierBg="bg-gradient-to-r from-gray-700 to-gray-500" />}
              </div>

              {results.silver === null && (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 text-sm">
                  <p className="text-yellow-800"><strong>Note:</strong> Silver tier systems are not available in California due to minimum efficiency requirements.</p>
                </div>
              )}

              <div className="bg-white rounded-xl shadow-lg p-6">
                <button onClick={resetCalculator} className="w-full py-4 bg-gray-600 text-white rounded-lg font-semibold text-lg hover:bg-gray-700 transition">Start New Calculation</button>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-400 p-6 rounded">
                <h3 className="font-bold text-blue-900 mb-2">Ready to Purchase?</h3>
                <p className="text-blue-800 mb-3">Click the <strong className="text-green-600">View Pricing & Buy Now</strong> buttons above to see current pricing and purchase systems directly online, or use the <strong>Call for Pricing</strong> button to contact us with the part numbers.</p>
                <p className="text-sm text-blue-700">Visit <a href="https://wholesalehvacdirect.com" className="underline font-semibold">wholesalehvacdirect.com</a> for more information.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HVACSizingCalculator;